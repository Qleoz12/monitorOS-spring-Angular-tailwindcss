package com.uniminuto.MonitorSistema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonitorSistemaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MonitorSistemaApplication.class, args);
	}

}
